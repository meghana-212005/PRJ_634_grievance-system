import { Navigate } from 'react-router-dom';

// Wrap a page with this to block access unless logged in as the right role.
// Usage: <ProtectedRoute role="citizen"><CitizenDashboard /></ProtectedRoute>
export default function ProtectedRoute({ children, role }) {
  const token = localStorage.getItem('token');
  const savedRole = localStorage.getItem('role');

  if (!token) return <Navigate to="/" replace />;
  if (role && savedRole !== role) return <Navigate to="/" replace />;

  return children;
}
