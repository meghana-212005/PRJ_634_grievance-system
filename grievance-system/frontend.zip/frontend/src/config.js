// Flip this to false the moment your teammate's backend is running.
// Nothing else in the app needs to change — every page calls the functions
// in api/grievanceApi.js, which check this flag internally.
export const DEMO_MODE = false;
