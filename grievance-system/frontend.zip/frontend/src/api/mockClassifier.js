/**
 * Stand-in for the backend's real NLP classifier (BERT/Transformer model
 * your teammate is building). This keeps the frontend demo functional and
 * shows category assignment working end-to-end, without needing the real
 * model. Swap-out point: once the backend classifies grievances for real,
 * this file is simply never called — grievanceApi.submitGrievance already
 * stops sending category from the frontend, and DEMO_MODE off means the
 * backend's response (with its real category) is what gets shown instead.
 */

const KEYWORD_MAP = [
  { category: 'Water Supply', keywords: ['water', 'leak', 'pipe', 'tap', 'sewage', 'drainage'] },
  { category: 'Roads', keywords: ['road', 'pothole', 'street', 'traffic', 'footpath', 'bridge'] },
  { category: 'Electricity', keywords: ['electric', 'power', 'light', 'transformer', 'wire', 'streetlight'] },
  { category: 'Sanitation', keywords: ['garbage', 'trash', 'waste', 'sanitation', 'dump', 'clean'] },
];

export function classifyGrievance(title, description) {
  const text = `${title} ${description}`.toLowerCase();
  for (const { category, keywords } of KEYWORD_MAP) {
    if (keywords.some((kw) => text.includes(kw))) {
      return category;
    }
  }
  return 'Other';
}
